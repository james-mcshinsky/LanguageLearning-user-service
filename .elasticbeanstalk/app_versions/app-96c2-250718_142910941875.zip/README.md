# LanguageLearning-Website

This project is a simple prototype for a streaming-based language learning platform. It includes a login page and a basic video library.

## Running the site

All of the front-end code lives in the `src/` directory. The entry file uses ES
modules handled by Vite, so opening `src/index.html` directly will not load the
app correctly. Instead run Vite's dev server during development:

```bash
npm run dev
```

This serves the application on a local port (usually `http://localhost:5173`).
For a production build run:

```bash
npm run build
```

Serve the files generated in the `dist/` folder with any static file server.

Before logging in you must create a user on the backend. Use the `/signup` endpoint to register a username and password, then authenticate with those credentials. For example:

```bash
curl -X POST http://127.0.0.1:8000/signup \
  -H "Content-Type: application/json" \
  -d '{"username": "test", "password": "test"}'
```

After signing up you can log in with the same credentials. Once authenticated the home screen displays a recommended feed of at least eight videos. Clicking a thumbnail loads the video in a player, shows a comprehension question at the end, and then loads a refreshed list of recommendations.

For development convenience you can also log in with the temporary credentials `Test`/`Test`. This bypasses backend authentication and should be removed before deploying to production.

## Development Setup

Install JavaScript dependencies before running tests or the linter.

```bash
npm install   # install dependencies
npm run lint  # run ESLint
npm test      # run unit tests
```

If your environment restricts network access, make sure the `node_modules/`
directory is already populated or enable internet access so `npm install` can
download the required packages.

## Running the backend

The `backend/` directory contains a small FastAPI server. Install the Python
dependencies and start the server with Uvicorn:

```bash
pip install -r backend/requirements.txt
uvicorn backend.main:app --reload
```
This requirements file now includes `httpx` so backend tests using Starlette's
`TestClient` run without additional packages.

This launches the API at `http://127.0.0.1:8000`. A health check endpoint is
available at `/health`.

The backend uses four optional environment variables:

- `DATABASE_URL` specifies the SQLAlchemy connection string. It defaults to
  `sqlite:///./users.db`.
- `REDIS_URL` sets the Redis connection string. The default is
  `redis://localhost`.
- `CORS_ORIGINS` defines allowed origins for cross-origin requests. It defaults to `*`.
- `SEED_DATA` controls inserting sample records on startup. Set to `true` to
  populate the database if it's empty.

### Video recommendations

`GET /api/videos/recommendations?user_id=<id>&limit=<n>` returns a list of videos
for the user ordered by score. Each item contains `id`, `title`,
`thumbnail_url` and the number of previously unseen words in the video under
`new_word_count`. The optional `limit` parameter defaults to 20.

Recommendations are recalculated whenever the user's word bank changes. After a quiz answer is submitted and the vocabulary is updated, the cached feed is cleared so the next visit to the home screen fetches a new list tailored to the updated words.

## Configuring the API base URL

API requests are prefixed with the value of `window.API_BASE`. By default this
variable is empty so all calls go to the current origin. Set it before loading
the Vite entry script when your backend lives elsewhere:

```html
<script>window.API_BASE = 'http://127.0.0.1:8000';</script>
<script type="module" src="/main.tsx"></script>
```

All fetch calls go through the helper in `src/api.ts`, so the prefix is applied
automatically.

If your deployment platform supports injecting environment variables, define an
`API_BASE` variable that populates `window.API_BASE` to customize the API host.
The older `__API_BASE__` placeholder is no longer used.


## Deploying to AWS

The backend can be containerized and deployed on AWS while the static frontend
is served from S3/CloudFront or AWS Amplify.

### 1. Build and push the backend image to ECR

1. Create an ECR repository (replace the name if desired):

   ```bash
   aws ecr create-repository --repository-name language-learning-backend
   ```

2. Authenticate Docker to your registry:

   ```bash
   aws ecr get-login-password --region <region> \
     | docker login --username AWS --password-stdin <account_id>.dkr.ecr.<region>.amazonaws.com
   ```

3. Build the image from the repository root using the included `Dockerfile`:

   ```bash
   docker build -t language-learning-backend .
   ```

4. Tag and push the image to ECR:

   ```bash
   docker tag language-learning-backend:latest \
     <account_id>.dkr.ecr.<region>.amazonaws.com/language-learning-backend:latest
   docker push <account_id>.dkr.ecr.<region>.amazonaws.com/language-learning-backend:latest
   ```

5. Alternatively run the helper script to build, tag and push in one step:
   ```bash
   AWS_ACCOUNT_ID=<account_id> AWS_REGION=<region> ./deploy-aws.sh
   ```
   Run `eb init` beforehand to configure Elastic Beanstalk. If you have not
   created the environment yet, launch it with `eb create` (the script assumes
   the environment already exists and will simply call `eb deploy`).

### 2. Deploying the container

- **Elastic Beanstalk** – create a **Docker Compose** environment using the
  provided `docker-compose.yml`. Run `eb init` and then `eb create` to launch
  the services. Environment variables such as `DATABASE_URL` and `REDIS_URL` can
  be set in the console or with `eb setenv`.

- **ECS/Fargate** – define a task pointing to the ECR image, expose port `8000`
  and set environment variables inside the container definition. Launch the task
  in a service (optionally behind an Application Load Balancer).

### 3. Setting environment variables

- **Elastic Beanstalk**: run `eb setenv DATABASE_URL=... REDIS_URL=...` or use
  the environment configuration page to specify each variable.
- **ECS**: add the variables to the container section of the task definition
  JSON or through the console.

#### Elastic Beanstalk example

You can store the connection strings for an RDS database and an ElastiCache
cluster as environment variables. After creating the resources, note their
endpoints and run:

```bash
eb setenv DATABASE_URL=postgresql://user:pass@db-instance.abc123.region.rds.amazonaws.com:5432/appdb \
           REDIS_URL=redis://cache.abc123.region.cache.amazonaws.com:6379
```

Use `eb printenv` to verify the values. The backend connects to the RDS instance
and Redis cluster using these settings.
### 4. Hosting the frontend

1. Copy the contents of the `src/` directory to an S3 bucket and enable static
   website hosting on the bucket.
2. (Optional) Create a CloudFront distribution with the bucket as the origin to
   serve the files over HTTPS and with caching, or use AWS Amplify to host the
   static site directly from the repository.
3. Run `scripts/deploy-frontend.sh <bucket>` (or set `DEPLOY_BUCKET` and omit the
   argument) to build the project and sync the resulting `dist/` folder to S3.

### 5. Pointing the frontend to the API

Add a script before the Vite entry in `src/index.html` that defines the backend
URL:

```html
<script>window.API_BASE = 'https://your-backend.example.com';</script>
<script type="module" src="/main.tsx"></script>
```

This replaces the old `script.js`/`__API_BASE__` approach.

### 6. Beginner checklist

If you are new to AWS, these steps provide additional context before going
through the commands above:

1. **Create an AWS account** – visit [aws.amazon.com](https://aws.amazon.com)
   and follow the registration process. A credit card is required but the free
   tier covers most small experiments.
2. **Install the AWS CLI** – download it from the [official documentation](https://docs.aws.amazon.com/cli/).
   After installation run `aws configure` and enter your access key, secret key,
   default region (for example `us-east-1`) and preferred output format.
3. **Clone this repository** – if you haven’t already, run:

   ```bash
   git clone https://github.com/your-user/LanguageLearning-Website.git
   cd LanguageLearning-Website
   ```

4. **Prepare your backend image** – build the Docker image as shown in step 1
   above and push it to ECR. Make sure Docker is installed and running locally.
5. **Deploy with Elastic Beanstalk or ECS** – create the environment and supply
   the image URI from ECR. For Elastic Beanstalk, use the `docker-compose.yml`
   file with `eb init` followed by `eb create` to start the Compose services.
6. **Upload the frontend** – copy the `src/` files to an S3 bucket or connect
   the repository to AWS Amplify for automated deployments.

These steps map directly onto the numbered sections above but include the basic
setup that first‑time AWS users often need.

## How Git relates to AWS

Git stores the history of this project. When you push changes to GitHub you are
updating the canonical copy of the code. AWS does not automatically read from
your Git repository. Instead you either:

1. Build a Docker image from the code and push that image to AWS Elastic
   Container Registry.
2. Deploy the pushed image using Elastic Beanstalk, ECS or another service.
   These services fetch the image from ECR and run it in containers.

Many teams automate this workflow. For example, a GitHub Actions pipeline can
build the Docker image on every commit to `main` and push it to ECR. A further
step can trigger an Elastic Beanstalk or ECS deployment. In this setup the
relationship between Git and AWS is mediated by the build process: Git retains
your source code, while AWS hosts the resulting container and static assets.

## Full AWS deployment walkthrough

Follow this sequence if you want a single step-by-step guide that covers everything from cloning the code through running a live site.

1. **Install tooling**
   - Create an AWS account if you do not already have one.
   - Install the [AWS CLI](https://docs.aws.amazon.com/cli/) and run `aws configure` to supply your credentials and default region.
   - Install Docker to build container images.
   - Install the [Elastic Beanstalk CLI](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/eb-cli3.html) if you plan to deploy with Elastic Beanstalk.

2. **Clone the repository and install dependencies**
   ```bash
   git clone https://github.com/your-user/LanguageLearning-Website.git
   cd LanguageLearning-Website
   npm install
   ```
   If you want to run the backend locally, also install the Python requirements:
   ```bash
   pip install -r backend/requirements.txt
   ```

3. **Build the backend Docker image**
   ```bash
   docker build -t language-learning-backend .
   ```

4. **Create an ECR repository and push the image**
   ```bash
   aws ecr create-repository --repository-name language-learning-backend
   aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <account_id>.dkr.ecr.<region>.amazonaws.com
   docker tag language-learning-backend:latest <account_id>.dkr.ecr.<region>.amazonaws.com/language-learning-backend:latest
   docker push <account_id>.dkr.ecr.<region>.amazonaws.com/language-learning-backend:latest
   ```

5. **Deploy the container**
   - *Elastic Beanstalk*
     ```bash
     eb init --platform docker --region <region>
     eb create language-learning-env
     eb deploy
     ```
   - *ECS/Fargate* – create a task definition pointing to the ECR image, then launch it in a service.

6. **Set environment variables**
   Use `eb setenv` or the ECS console to define `DATABASE_URL`, `REDIS_URL` and other variables. The backend reads them on startup.

7. **Build and upload the frontend**
   ```bash
   npm run build
   aws s3 sync dist/ s3://<bucket-name> --delete
   ```
   Enable static website hosting on the bucket or attach it to a CloudFront distribution. You can also link the repository to AWS Amplify for automatic deploys.

8. **Point the frontend to the API**
   Edit `src/index.html` so it sets `window.API_BASE` to your backend's URL before loading the Vite script.

9. **Verify everything is running**
   Visit the CloudFront or S3 URL to load the site. Log in with the credentials you created via the API. Repeat the build/push/deploy cycle whenever you update the code.

This walkthrough ties together the detailed sections above in a single linear sequence so newcomers can deploy without jumping between topics.

