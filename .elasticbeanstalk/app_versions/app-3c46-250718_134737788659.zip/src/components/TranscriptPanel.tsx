import React, { useEffect, useRef, useState } from 'react';
import { apiFetch } from '../api';

interface Token {
  word_id: number;
  text: string;
  start_sec: number;
  end_sec: number;
}

interface Line {
  start_sec: number;
  end_sec: number;
}

interface Props {
  videoId: number;
  userId: number;
  player: any;
  onWordUpdated: () => void;
}

export default function TranscriptPanel({ videoId, userId, player, onWordUpdated }: Props) {
  const [lines, setLines] = useState<Line[]>([]);
  const [tokens, setTokens] = useState<Token[]>([]);
  const [knownWords, setKnownWords] = useState<Set<number>>(new Set());
  const [active, setActive] = useState(-1);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    Promise.all([
      apiFetch(`/api/videos/${videoId}/transcript`).then(r => r.json()),
      apiFetch(`/api/videos/${videoId}/tokens`).then(r => r.json()),
      apiFetch(`/api/user/words?user_id=${userId}`).then(r => r.json())
    ]).then(([l, t, w]) => {
      setLines(l);
      setTokens(t);
      setKnownWords(new Set(w.map((x: any) => x.word_id)));
    });
  }, [videoId, userId]);

  useEffect(() => {
    if (!player) return;
    const interval = setInterval(() => {
      const current = player.getCurrentTime ? player.getCurrentTime() : 0;
      const idx = lines.findIndex(l => current >= l.start_sec && current < l.end_sec);
      setActive(idx);
    }, 500);
    return () => clearInterval(interval);
  }, [player, lines]);

  const updateWord = async (wordId: number) => {
    await apiFetch(`/api/user/words/${wordId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, mastery_level: 'learning' })
    });
    setKnownWords(new Set([...knownWords, wordId]));
    onWordUpdated();
  };

  return (
    <div ref={containerRef}>
      {lines.map((l, i) => (
        <div key={i} className={i === active ? 'active' : ''}>
          {tokens.filter(t => t.start_sec >= l.start_sec && t.end_sec <= l.end_sec).map(t => (
            <span
              key={t.word_id}
              className={knownWords.has(t.word_id) ? 'known' : 'unknown'}
              onClick={() => updateWord(t.word_id)}
            >
              {t.text} 
            </span>
          ))}
        </div>
      ))}
    </div>
  );
}
